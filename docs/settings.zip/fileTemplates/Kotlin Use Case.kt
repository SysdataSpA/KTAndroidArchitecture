#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end
import it.sysdata.ktandroidarchitecturecore.exception.Failure
import it.sysdata.ktandroidarchitecturecore.functional.Either
import it.sysdata.ktandroidarchitecturecore.interactor.ActionParams
import it.sysdata.ktandroidarchitecturecore.interactor.UseCase
#parse("File Header.java")
class ${NAME}UseCase : UseCase<${NAME}UseCaseResult,${NAME}UseCaseParams>() {
 override suspend fun run(params: ${NAME}UseCaseParams): Either<Failure, ${NAME}UseCaseResult> {
        return Either.Right(${NAME}UseCaseResult(params))
    }
}

data class ${NAME}UseCaseParams(val param1:Any) : ActionParams()

data class ${NAME}UseCaseResult(val params:${NAME}UseCaseParams)
